pte_t* walkpgdir(pde_t*, const void*, int);
int munprotect(void*, int);
int mprotect(void*, int);


