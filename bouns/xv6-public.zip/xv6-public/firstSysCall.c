#include "types.h"
#include "stat.h"
#include "user.h"

int main(void) 
{
printf(1, "Note: Unix V6 was released in year %d\n", getyear());
printf(1,"ReadCount = %d\n", getReadCount());//edited 
    exit();
}
